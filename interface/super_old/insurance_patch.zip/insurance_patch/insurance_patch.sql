
CREATE TABLE IF NOT EXISTS `tbl_allcare_insurance1to1` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL DEFAULT '0',
  `insurance_company_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`pid`),
  KEY `id` (`id`),
  KEY `pid2` (`pid`),
  KEY `pid3` (`pid`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tbl_allcare_insurance1to1_fieldmapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `POS_id` int(10) NOT NULL,
  `Grouping_ID` int(10) NOT NULL,
  `Grouping_Name` varchar(50) NOT NULL,
  `Table_ID` int(10) NOT NULL,
  `Field_ID` int(10) NOT NULL,
  `isVisible` enum('Y','N') NOT NULL DEFAULT 'Y',
  `Created_Date` datetime NOT NULL,
  `Updated_Date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tbl_allcare_insurance1ton` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `insurance_company_id` int(10) NOT NULL,
  `Recordset_ID` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tbl_allcare_insurance1ton_fieldmapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `POS_id` int(10) NOT NULL,
  `Recordset_ID` int(10) NOT NULL,
  `Recordset_Name` varchar(50) NOT NULL,
  `Table_ID` int(10) NOT NULL,
  `Field_ID` int(10) NOT NULL,
  `isVisible` enum('Y','N') NOT NULL DEFAULT 'Y',
  `Created_Date` datetime NOT NULL,
  `Updated_Date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tbl_allcare_tablemeta_insurance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `table_ID` int(10) NOT NULL,
  `table_Name` varchar(50) NOT NULL,
  `field_ID` int(10) NOT NULL,
  `field_Name` varchar(50) NOT NULL,
  `is_field_editable` enum('Y','N') NOT NULL DEFAULT 'N',
  `created_Date` datetime NOT NULL,
  `updated_Date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

